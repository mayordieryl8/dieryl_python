import pymysql

def CreateNewAccount(email_address, password):
    connection = pymysql.connect("db4free.net","aeiou_test","aeiou_test","aeiou_test",3306)
    cursor = connection.cursor()
    qry = """INSERT
    INTO tblusers(user_email, user_pwd)
    VALUES ('{email_address}', '{password}')""".format(email_address = email_address, password = password)

    cursor.execute(qry)
    connection.commit

    cursor.close
    connection.close
    success_message = "Account successfully created!"
    return success_message
