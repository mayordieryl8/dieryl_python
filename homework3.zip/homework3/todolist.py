from flask import Flask, render_template, url_for, request
import model

app = Flask(__name__)


@app.route('/')
def Home():
    return render_template('index.html')


@app.route('/terms-of-use')
def TermsOfUse():
    return render_template('terms-of-use.html')


@app.route('/privacy')
def Privacy():
    return render_template('privacy.html')


@app.route('/about-us')
def AboutUs():
    return render_template('about-us.html')


@app.route('/sign-in', methods =  ['GET', 'POST'])
def SignIn():
    return  render_template('sign-in.html')


@app.route('/sign-up', methods =  ['GET', 'POST'])
def SignUp():
    if request.method == 'GET':
        return  render_template('sign-up.html')
    else:
        email_address = request.form['email_address']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if email_address == '' or password == '' or confirm_password == '':
            if email_address == '':
                email_address_error = 'Email address is required.'
            else:
                email_address_error =''
            if password == '':
                password_error = 'Password is required.'
            else:
                password_error = ''
            if confirm_password == '':
                confirm_password_error = 'Confirmed password is required.'
            else:
                confirm_password_error = ''
            return  render_template('sign-up.html',
            email_address = email_address,
            password = password,
            email_address_error = email_address_error,
            password_error = password_error,
            confirm_password_error = confirm_password_error)
        elif len(password) < 8:
            password_error = 'Password should have at least 8 characters length.'
            return render_template('sign-up.html',
            email_address = email_address,
            email_address_error = '',
            password_error = password_error,
            confirm_password_error = '')
        elif password != confirm_password:
            confirm_password = 'Password mismatch. Please check and try again.'
            return render_template('sign-up.html',
            email_address = email_address,
            email_address_error = '',
            password_error = '',
            confirm_password_error = confirm_password)
        else:
            success_message = model.CreateNewAccount(email_address, password)
            email_address_error =''
            password_error = ''
            confirm_password_error = ''
            # success_message = 'Account successfully created.'
            return  render_template('sign-up.html',
            success_message = success_message)


if __name__ == '__main__':
    app.run(port = 7000, debug = True)
